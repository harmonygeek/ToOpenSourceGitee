/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../workspace/Javascript/StageConversion/3/working/okhttpstageconversion/entry/src/main/ets/Application/AbilityStage.ts?entry":
/*!************************************************************************************************************************************************!*\
  !*** ../../../../../workspace/Javascript/StageConversion/3/working/okhttpstageconversion/entry/src/main/ets/Application/AbilityStage.ts?entry ***!
  \************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var _ohos_application_AbilityStage_1  = globalThis.requireNapi('application.AbilityStage') || (isSystemplugin('application.AbilityStage', 'ohos') ? globalThis.ohosplugin.application.AbilityStage : isSystemplugin('application.AbilityStage', 'system') ? globalThis.systemplugin.application.AbilityStage : undefined);
class MyAbilityStage extends _ohos_application_AbilityStage_1 {
    onCreate() {
        console.log("[Demo] MyAbilityStage onCreate");
    }
}
globalThis.exports.default = MyAbilityStage;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../workspace/Javascript/StageConversion/3/working/okhttpstageconversion/entry/src/main/ets/Application/AbilityStage.ts?entry"](0, __webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=AbilityStage.js.map