/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************************************************************************************************************************!*\
  !*** ../../../../../workspace/Javascript/StageConversion/3/working/okhttpstageconversion/entry/src/main/ets/pages/okio_sample.ets?entry ***!
  \******************************************************************************************************************************************/
class Okio_sample extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.__message = new ObservedPropertySimple('Hello World', this, "message");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    render() {
        Column.create();
        Column.debugLine("pages/okio_sample.ets(7:5)");
        Column.width('100%');
        Column.margin({ top: 5, bottom: 100 });
        Column.height('80%');
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(8:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Navigator.create({ target: 'pages/index', type: NavigationType.Push });
        Navigator.debugLine("pages/okio_sample.ets(9:9)");
        Text.create('BACK');
        Text.debugLine("pages/okio_sample.ets(10:11)");
        Text.fontSize(12);
        Text.border({ width: 1 });
        Text.padding(10);
        Text.fontColor(0x000000);
        Text.borderColor(0x317aff);
        Text.pop();
        Navigator.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(18:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Write/ReadUtf8');
        Button.debugLine("pages/okio_sample.ets(19:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(27:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('EncodeBase64');
        Button.debugLine("pages/okio_sample.ets(28:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(36:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('okhttp EncodeBase64');
        Button.debugLine("pages/okio_sample.ets(37:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(45:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('okhttp DecodeBase64');
        Button.debugLine("pages/okio_sample.ets(46:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(54:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('okhttp EncodeHex');
        Button.debugLine("pages/okio_sample.ets(55:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(63:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('encode MD5Hex');
        Button.debugLine("pages/okio_sample.ets(64:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(72:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('okhttp DecodeHex');
        Button.debugLine("pages/okio_sample.ets(73:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(81:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('FileWrite & Read');
        Button.debugLine("pages/okio_sample.ets(82:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/okio_sample.ets(90:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Append & Read');
        Button.debugLine("pages/okio_sample.ets(91:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
        });
        Button.pop();
        Flex.pop();
        Column.pop();
    }
}
loadDocument(new Okio_sample("1", undefined, {}));

/******/ })()
;
//# sourceMappingURL=okio_sample.js.map