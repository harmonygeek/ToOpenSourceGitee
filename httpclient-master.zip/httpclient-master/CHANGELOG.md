##1.0.0

1. Changed from gradle project to hvigor project.

2. Optimized and added english readme



