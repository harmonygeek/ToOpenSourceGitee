/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************************************************************************************!*\
  !*** ../../../../../../../../staging/22_06/httpclient_5/entry/src/main/ets/pages/index.ets?entry ***!
  \***************************************************************************************************/
/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var router = globalThis.requireNativeModule('system.router');
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params) {
        super(compilerAssignedUniqueChildId, parent);
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id());
    }
    render() {
        Column.create();
        Column.debugLine("pages/index.ets(22:5)");
        Column.width('100%');
        Column.margin({ top: 5 });
        Column.height('100%');
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/index.ets(23:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Core');
        Button.debugLine("pages/index.ets(24:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(25);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
            router.push({
                uri: 'pages/core'
            });
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/index.ets(34:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Sample');
        Button.debugLine("pages/index.ets(35:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(25);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
            router.push({
                uri: 'pages/sample'
            });
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/index.ets(45:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('UploadAndDownload');
        Button.debugLine("pages/index.ets(46:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(18);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
            router.push({
                uri: 'pages/uploadAndDownload'
            });
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/index.ets(56:9)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Auxiliary');
        Button.debugLine("pages/index.ets(57:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(25);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
            router.push({
                uri: 'pages/auxiliary'
            });
        });
        Button.pop();
        Flex.pop();
        Flex.create({ direction: FlexDirection.Column });
        Flex.debugLine("pages/index.ets(67:7)");
        Flex.height('10%');
        Flex.width('100%');
        Flex.padding(10);
        Button.createWithLabel('Crypto');
        Button.debugLine("pages/index.ets(68:9)");
        Button.width('80%');
        Button.height('100%');
        Button.fontSize(25);
        Button.fontColor(0xCCCCCC);
        Button.align(Alignment.Center);
        Button.margin(10);
        Button.onClick((event) => {
            router.push({
                uri: 'pages/crypto'
            });
        });
        Button.pop();
        Flex.pop();
        Column.pop();
    }
}
loadDocument(new Index("1", undefined, {}));

/******/ })()
;
//# sourceMappingURL=index.js.map