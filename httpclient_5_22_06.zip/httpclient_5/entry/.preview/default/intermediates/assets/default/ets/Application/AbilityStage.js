/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../staging/22_06/httpclient_5/entry/src/main/ets/Application/AbilityStage.ts?entry":
/*!***************************************************************************************************************!*\
  !*** ../../../../../../../../staging/22_06/httpclient_5/entry/src/main/ets/Application/AbilityStage.ts?entry ***!
  \***************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var _ohos_application_AbilityStage_1  = globalThis.requireNapi('application.AbilityStage') || (isSystemplugin('application.AbilityStage', 'ohos') ? globalThis.ohosplugin.application.AbilityStage : isSystemplugin('application.AbilityStage', 'system') ? globalThis.systemplugin.application.AbilityStage : undefined);
class MyAbilityStage extends _ohos_application_AbilityStage_1 {
    onCreate() {
        console.log("[Demo] MyAbilityStage onCreate");
    }
}
globalThis.exports.default = MyAbilityStage;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../../../staging/22_06/httpclient_5/entry/src/main/ets/Application/AbilityStage.ts?entry"](0, __webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=AbilityStage.js.map