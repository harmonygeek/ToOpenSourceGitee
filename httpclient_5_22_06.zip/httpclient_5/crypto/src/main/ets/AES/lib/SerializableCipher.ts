/*
 * Copyright (C) 2022 Huawei Device Co., Ltd.
 * Licensed under the MIT License, (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://opensource.org/licenses/MIT
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { WordArray } from '../../lib-WordArray';
import { Cipher } from './Cipher';
import { BufferedBlockAlgorithmConfig } from '../../BufferedBlockAlgorithmConfig';
import { OpenSSL } from '../format/OpenSSL';
import { CipherParams } from './CipherParams';
import { Local_Formatter } from '../format/Local_Formatter';

export class SerializableCipher {
  public static cfg: BufferedBlockAlgorithmConfig = {
    blockSize: 4,
    iv: new WordArray([]),
    format: OpenSSL
  };

  /**
   * Encrypts a message.
   *
   * @param cipher The cipher algorithm to use.
   * @param message The message to encrypt.
   * @param key The key.
   * @param cfg (Optional) The configuration options to use for this operation.
   *
   * @return A cipher params object.
   *
   * @example
   *
   *     let ciphertextParams = SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
   *     let ciphertextParams = SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
   *     let ciphertextParams = SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, {
   *       iv: iv,
   *       format: CryptoJS.format.OpenSSL
   *     });
   */
  public static encrypt(
    cipher: typeof Cipher,
    message: WordArray | string,
    key: WordArray,
    cfg?: BufferedBlockAlgorithmConfig
  ): CipherParams {
    // Apply config defaults
    const config = Object.assign({}, this.cfg, cfg);

    // Encrypt
    const encryptor = cipher.createEncryptor(key, config);
    const ciphertext = encryptor.finalize(message);

    // Create and return serializable cipher params
    return new CipherParams({
      ciphertext: ciphertext,
      key: key,
      iv: encryptor.cfg.iv,
      algorithm: cipher,
      mode: (<any> encryptor.cfg).mode,
      padding: (<any> encryptor.cfg).padding,
      blockSize: encryptor.cfg.blockSize,
      formatter: config.format
    });
  }

  /**
   * Decrypts serialized ciphertext.
   *
   * @param cipher The cipher algorithm to use.
   * @param ciphertext The ciphertext to decrypt.
   * @param key The key.
   * @param cfg (Optional) The configuration options to use for this operation.
   *
   * @return The plaintext.
   *
   * @example
   *
   *     let plaintext = SerializableCipher.decrypt(
   *         AESAlgorithm,
   *         formattedCiphertext,
   *         key, {
   *             iv: iv,
   *             format: CryptoJS.format.OpenSSL
   *         }
   *     );
   *
   *     let plaintext = SerializableCipher.decrypt(
   *         AESAlgorithm,
   *         ciphertextParams,
   *         key, {
   *             iv: iv,
   *             format: CryptoJS.format.OpenSSL
   *         }
   *     );
   */
  public static decrypt(
    cipher: typeof Cipher,
    ciphertext: CipherParams | string,
    key: WordArray,
    optionalCfg?: BufferedBlockAlgorithmConfig
  ): WordArray {
    // Apply config defaults
    const cfg = Object.assign({}, this.cfg, optionalCfg);

    if(!cfg.format) {
      throw new Error('could not determine format');
    }

    // Convert string to CipherParams
    ciphertext = this._parse(ciphertext, cfg.format);

    if(!ciphertext.ciphertext) {
      throw new Error('could not determine ciphertext');
    }

    // Decrypt
    const plaintext = cipher.createDecryptor(key, cfg).finalize(ciphertext.ciphertext);

    return plaintext;
  }

  /**
   * Converts serialized ciphertext to CipherParams,
   * else assumed CipherParams already and returns ciphertext unchanged.
   *
   * @param ciphertext The ciphertext.
   * @param format The formatting strategy to use to parse serialized ciphertext.
   *
   * @return The unserialized ciphertext.
   *
   * @example
   *
   *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
   */
  public static _parse(ciphertext: CipherParams | string, format: Local_Formatter): CipherParams {
    if(typeof ciphertext === 'string') {
      return format.parse(ciphertext);
    } else {
      return ciphertext;
    }
  }
}