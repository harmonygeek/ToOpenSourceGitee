/*
 * Copyright (C) 2022 Huawei Device Co., Ltd.
 * Licensed under the MIT License, (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://opensource.org/licenses/MIT
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { WordArray } from '../../lib-WordArray';
import { EPadding } from '../pad/EPadding';

export class AnsiX923 {
  public static pad(data: WordArray, blockSize: number): void {
    // Shortcuts
    var dataSigBytes = data.sigBytes;
    var blockSizeBytes = blockSize * 4;

    // Count padding bytes
    var nPaddingBytes = blockSizeBytes - dataSigBytes % blockSizeBytes;

    // Compute last byte position
    var lastBytePos = dataSigBytes + nPaddingBytes - 1;

    // Pad
    data.clamp();
    data.words[lastBytePos >>> 2] |= nPaddingBytes << (24 - (lastBytePos % 4) * 8);
    data.sigBytes += nPaddingBytes;
  }

  public static unpad(data: WordArray): void {
    // Get number of padding bytes from last byte
    var nPaddingBytes = data.words[(data.sigBytes - 1) >>> 2] & 0xff;

    // Remove padding
    data.sigBytes -= nPaddingBytes;
  }
}
const _: EPadding = AnsiX923;