/*
 * Copyright (C) 2022 Huawei Device Co., Ltd.
 * Licensed under the MIT License, (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://opensource.org/licenses/MIT
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { BlockCipherModeAlgorithm } from './BlockCipherModeAlgorithm';

export class CFBDecryptor extends BlockCipherModeAlgorithm {
  private _prevBlock:Array<number>
  /**
   * Processes the data block at offset.
   *
   * @param words The data words to operate on.
   * @param offset The offset where the block starts.
   *
   * @example
   *
   *     mode.processBlock(data.words, offset);
   */
  public processBlock(words: Array<number>, offset: number) {
    // Shortcuts
    var cipher = this._cipher;
    var blockSize = cipher.cfg.blockSize;
    if (blockSize == 0 || blockSize == undefined) {
      blockSize = 1;
    }

    // Remember this block to use with next block
    var thisBlock = words.slice(offset, offset + blockSize);

    this.generateKeystreamAndEncrypt.call(this, words, offset, blockSize, cipher);

    // This block becomes the previous block
    this._prevBlock = thisBlock;
  }

  generateKeystreamAndEncrypt(words, offset, blockSize, cipher) {
    var keystream;

    // Shortcut
    var iv = this._iv;

    // Generate keystream
    if (iv) {
      keystream = iv.slice(0);

      // Remove IV for subsequent blocks
      this._iv = undefined;
    } else {
      keystream = this._prevBlock;
    }
    cipher.encryptBlock(keystream, 0);

    // Encrypt
    for (var i = 0; i < blockSize; i++) {
      words[offset + i] ^= keystream[i];
    }
  }
}