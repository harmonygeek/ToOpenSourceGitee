##1.0.1

1. Staging build conversion.

2. API-9 migration

3. Issue fixes

##1.0.0

1. Changed from gradle project to hvigor project.

2. Optimized and added english readme




