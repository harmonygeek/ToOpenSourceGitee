# okhttp_ohos

okhttp_ohos:HTTP is the way modern applications network. It’s how we exchange data & media. Doing HTTP efficiently makes your stuff load faster and saves bandwidth.
OkHttp is an HTTP client.

## Usage Instructions
Import okhttp as below from node_modules after adding okhttp_ohos module in project root directory:
``
import okhttp from 'okhttp_ohos';
``

1. For using HTTP method GET with interceptors and connectTimeout :
``
 const myInterceptor = okhttp.interceptors.request.use(req => {
            req.url = req.url + "&foo3=bar3";
            return req;
        });
        var reqBuilder = new okhttp.RequestBuilder();
        reqBuilder.interceptors.request.use(req => {
            req.url = req.url + "&foo4=bar4";
            return req;
        });
        reqBuilder.interceptors.response.use(resp => {
            resp.responseCode = 404;
            return resp;
        });
        reqBuilder.GET("https://postman-echo.com/get?foo1=bar1&foo2=bar2").header("Content-Type", "application/json").connectTimeout(10000).buildAndExecute().then(this.onComplete).catch(this.onError);
        okhttp.interceptors.request.eject(myInterceptor);
``

2.For using HTTP method POST :
``
new okhttp.RequestBuilder().url("https://postman-echo.com/post").POST(okhttp.RequestBody.create("test123")).header("Content-Type", "application/json").connectTimeout(10000).buildAndExecute().then(this.onComplete).catch(this.onError);
``

3. For using HTTP method POST with 2 values:
``
new okhttp.RequestBuilder().url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create({
                a: 'a1', b: 'b1'
            }, new okhttp.MimeBuilder().contentType('application/json', 'charset', 'utf8').build()))
            .buildAndExecute().then(this.onComplete).catch(this.onError);
``

4. For using HTTP method POST with 3 values:
``
let fe_body = new okhttp.FormEncodingBuilder().add('key1', 'value1').add('key2', 'value2').build();
        new okhttp.RequestBuilder().url("https://postman-echo.com/post").POST(fe_body).buildAndExecute()
            .then(this.onComplete).catch(this.onError);
``

5. For using upload with an async:
``
let appInternalDir;
        // @ts-ignore
        await featureAbility.getContext().getCacheDir().then(function (result) {
            appInternalDir = result;
        });
        let fpath = appInternalDir + this.fileName;
        let fd = fileIO.openSync(fpath, 0o102, 0o666);
        // @ts-ignore
        fileIO.writeSync(fd, "text.txt file is uploaded", function (err, bytesWritten) {
            if (!err) {
                console.log("meta " + bytesWritten);
            }
        });
        fileIO.closeSync(fd);
        fpath = fpath.replace(appInternalDir, "internal://cache");
        var fileUploadBuilder = new okhttp.FileUploadBuilder().addFile(fpath).addData("name2", "value2");
        var fileObject = fileUploadBuilder.buildFile();
        var dataObject = fileUploadBuilder.buildData();
        await new okhttp.RequestBuilder().url(this.fileServer)
            .UPLOAD(fileObject, dataObject).buildAndExecute().then(this.onComplete).catch(this.onError);
``

6. For using HTTP method PUT:
``
new okhttp.RequestBuilder().url("https://postman-echo.com/put")
            .PUT(okhttp.RequestBody.create({
                a: 'a1', b: 'b1'
            }, new okhttp.MimeBuilder().contentType('application/json', 'charset', 'utf8').build()))
            .buildAndExecute().then(this.onComplete).catch(this.onError);
``

7. For using HTTP method DELETE:
``
new okhttp.RequestBuilder().url("https://reqres.in/api/users/2")
            .DELETE()
            .buildAndExecute().then(this.onComplete).catch(this.onError);
``

8. For downloading file:
``
new okhttp.RequestBuilder().DOWNLOAD("https://archiveprogram.github.com/assets/img/direction/box2-home.png")
            .buildAndExecute().then(this.onDownloadTaskStart).catch(this.onError);
onDownloadTaskStart: function (downloadTask) {
    downloadTask.on('complete', () => {
        this.content = "Download Task Completed";
    })
}
``

## API/Interface Description

### RequestBody
**create(content : String/JSON Object of Key:Value pair): RequestBody;** 
 Create a RequestBody object

### RequestBuilder
**buildAndExecute(): void;**
 Build and execute RequestBuilder
 
**newCall(): void;**
 Execute request

**header(name:String,value:String): RequestBuilder;** 
Take key,value as input to build the header.

**connectTimeout(timeout:Long): RequestBuilder;** 
 Time period to establish connection with host.

**url(value:String): RequestBuilder;** 
 Take url as input to build url object

**GET(): RequestBuilder;** 
 Build a GET method

**PUT(body:RequestBody): RequestBuilder;** 
 Build a PUT method

**DELETE(): RequestBuilder;** 
 Build a DELETE method

**POST(): RequestBuilder;** 
 Build a POST method
 
**UPLOAD(files:Array, data:Array): RequestBuilder;** 
 Build a UPLOAD method

**CONNECT(): RequestBuilder;** 
 Build a CONNECT method
 
### MimeBuilder
**contentType(value:String): void;**
 Add MimeBuilder contentType.
 
### FormEncodingBuilder
**add(name:String,value:String) : void;**
 Take key,value to add data
 
**build(): void;** 
 Returns the RequestBody
 
### FileUploadBuilder
**addFile(furi : String): void;**
 Take file URI as input to push file

**addData(name:String,value:String): void;**
 Take key,value to add data

**buildFile(): void;**
 Build the file object to upload
 
**buildData(): void;**
 Build the data to upload


## Installation Instructions
1.For using okhttp_ohos module in sample application,include the below dependency in entry package.json after adding okhttp_ohos module in project root directory.

```
"dependencies": {
    "okhttp_ohos": "file:../okhttp_ohos"
  }
```

## Compatibility
Supports OpenHarmony API version 8 and above

## Directory Structure
````
|---- httpclient  
|     |---- entry  # sample app usage
|     |---- okhttp_ohos  # okhttp library
|           |---- index.ets  # External interface
|     |---- README.MD  # installation and usage                   
````

## Code Contribution
If you find any problems during usage, you can submit an [Issue](https://gitee.com/openharmony-tpc/httpclient/issues) to us. Of course, we also welcome you to send us [PR](https://gitee.com/openharmony-tpc/httpclient/pulls).

## Open source License
This project is based on [Apache License 2.0](https://gitee.com/openharmony-tpc/httpclient/blob/master/LICENSE) ，please enjoy and participate in open source freely.

