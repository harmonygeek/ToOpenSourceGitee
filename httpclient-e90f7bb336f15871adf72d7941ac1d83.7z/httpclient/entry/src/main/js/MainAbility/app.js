import Log from './log/log'
export default {
    onCreate() {
        Log.showInfo("Application onCreate");
    },
    onDestroy() {
        Log.showInfo("Application onDestroy");
    }
};
