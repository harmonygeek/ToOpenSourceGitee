/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import okhttp from 'okhttp_ohos';
import router from '@system.router';
import Log from '../../log/log';
import defaultConfigJSON from './defaultConfig.json';


export default {
    data: {
        status: "",
        content: "",
        echoServer: "http://www.yourserverfortest.com",
        client: new okhttp.OkHttpClient.Builder()
            .setConnectTimeout(10000)
            .setReadTimeout(10000)
            .setWriteTimeout(10000)
            .build()
    },
    onInit() {
           },
    showIndexView() {
        router.push({
            uri: 'pages/index/index'
        })
    },
    onComplete: function (result) {
        if (result.response) {
            this.status = result.response.responseCode;
        }
        if (result.response.result)
            this.content = result.response.result;
        else
            this.content = JSON.stringify(result.response);

        Log.showInfo("onComplete -> Status : " + this.status);
        Log.showInfo("onComplete -> Content : " + JSON.stringify(this.content));
    },
    onError: function (error) {
        Log.showInfo("onError -> Error : " + error);
        this.content = JSON.stringify(error);
        Log.showInfo("onError -> Content : " + JSON.stringify(this.content));
    },

    setDefaultUserAgent(){
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .addHeader("Content-Type", "application/json")
            .setDefaultUserAgent()
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },
    setDefaultContentType(){
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .addHeader("Content-Type", "application/json")
            .setDefaultContentType()
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },
    setUserAgent(){
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .addHeader("Content-Type", "application/json")
            .setDefaultUserAgent("My Application 1.0")
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },
    setContentType(){
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .setDefaultContentType("application/text")
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },
    defaultConfigJSON(){
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .setDefaultConfig(defaultConfigJSON)
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },

    setDebugModeFalse() {
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .addHeader("Content-Type", "application/json")
            .setdebugmode(false)
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    },
    setDebugModeTrue() {
        var request = new okhttp.Request.Builder()
            .url("https://postman-echo.com/post")
            .POST(okhttp.RequestBody.create("test123"))
            .addHeader("Content-Type", "application/json")
            .setdebugmode(true)
            .build();
        this.client.newCall(request).execute().then(this.onComplete).catch(this.onError);
    }
}