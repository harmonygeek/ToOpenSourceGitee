/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import router from '@system.router';

export default {
    data: {
        title: "",
        fileUri: '/data/data/com.openharmony.ohos.okioapplication/cache/test.txt'
    },
    onInit() {
    },
    showCoreJs() {
        router.push({
            uri: 'pages/core/core'
        })
    },
    showSampleJs() {
        router.push({
            uri: 'pages/samples/sample'
        })
    },
    showUploadAndDownloadJs() {
        router.push({
            uri: 'pages/uploadAndDownload/uploadAndDownload'
        })
    },
    showCompressionJs() {
        router.push({
            uri: 'pages/compression/compression'
        })
    },
    showOkioSampleJs() {
        router.push({
            uri: 'pages/okio_sample/okio_sample'
        })
    },
    showAuxiliaryJs() {
        router.push({
            uri: 'pages/auxiliary/auxiliary'
        })
    }

}
