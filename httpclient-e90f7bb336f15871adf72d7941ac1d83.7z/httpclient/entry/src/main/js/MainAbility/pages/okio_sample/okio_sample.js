/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import router from '@system.router';
import okio from 'okio';
import okhttp from 'okhttp_ohos';
import featureAbility from '@ohos.ability.featureAbility'
import fileio from '@ohos.fileio';
import Log from '../../log/log';

var byteStringObj = new okio.ByteString.ByteString('Hello world');
export default {
    data: {
        title: "",
        echoServer: "http://www.yourserverfortest.com",
        ioServer: "http://www.yourserverforio.com",
        writeUtfValue: "Hello World",
        writeInputValue : "Hello World",
        readUtfValue: "",
        encodeBase64Value:"Hello World",
        client: new okhttp.OkHttpClient.Builder().setConnectTimeout(10000).build()
    },
    onInit() {
    },
    showIndexView() {
        router.push({
            uri: 'pages/index/index'
        })
    },
    onComplete: function (result) {
        if (result.response) {
            this.status = result.response.responseCode;
        }
        if (result.response.result)
        this.content = result.response.result;
        else
        this.content = JSON.stringify(result.response);

        Log.showInfo("onComplete -> Status : " + this.status);
        Log.showInfo("onComplete -> Content : " + JSON.stringify(this.content));
    },

    onError: function (error) {
        this.status = "";
        this.content = error.data;
        Log.showInfo("onError -> Error : " + this.content);
    },

    getStringUtfValue(e) {
        this.writeUtfValue = e.text;
    },
    performWriteUtf8() {
        var buffer = new okio.Buffer();

        buffer.writeUtf8(this.writeUtfValue);
        this.readUtfValue = buffer.readUtf8();
        Log.showInfo("readUtfValue : "+this.readUtfValue);
    },
    encodeBase64() {
        let encodeBase64 = byteStringObj.encodeUtf8('Hello world').Base64();
        this.encodeBase64Value = JSON.stringify(encodeBase64);
        Log.showInfo("encodeBase64Value : "+this.encodeBase64Value);

    },
    getWriteValue(e) {
        this.writeInputValue = e.text;
    },

    okhttpEncodeBase64() {

        let encodeBase64 = byteStringObj.encodeUtf8('Hello world').Base64();
        this.encodeBase64Value = JSON.stringify(encodeBase64);

        var request = new okhttp.Request.Builder()
            .url(this.echoServer)
            .POST(okhttp.RequestBody.create(this.encodeBase64Value))
            .addHeader("Content-Type", "application/json")
            .build();

        this.client.newCall(request).enqueue(this.onComplete, this.onError);
    },

    onDeodeComplete: function (result) {
        if (result.response) {
            this.status = result.response.responseCode;
        }
        if (result.response.result)
        this.content = result.response.result;
        else
        this.content = JSON.stringify(result.response);

        let decodeBase64 = byteStringObj.decodeBase64(this.content);
        this.decodeBase64Value = JSON.stringify(decodeBase64);

        Log.showInfo("onDeodeComplete -> Status : " + this.status);
        Log.showInfo("onDeodeComplete -> Content : " + this.content);
        Log.showInfo("onDeodeComplete -> decodeBase64Value : " + this.decodeBase64Value);
    },

    onDecodeError: function (error) {
        this.status = "";
        this.content = error.data;
        Log.showInfo("onDecodeError -> Error : " + this.content);
    },

    okhttpDecodeBase64() {

        var request = new okhttp.Request.Builder()
            .url(this.ioServer)
            .POST(okhttp.RequestBody.create(this.encodeBase64Value))
            .addHeader("Content-Type", "application/json")
            .build();

        this.client.newCall(request).enqueue(this.onDeodeComplete, this.onDecodeError);
    },

    okhttpEncodeHex() {

        let encodeHex = byteStringObj.encodeUtf8('Hello world').Hex();
        this.encodeHexValue = JSON.stringify(encodeHex);

        var request = new okhttp.Request.Builder()
            .url(this.echoServer)
            .POST(okhttp.RequestBody.create(this.encodeHexValue))
            .addHeader("Content-Type", "application/json")
            .build();

        this.client.newCall(request).enqueue(this.onComplete, this.onError);
    },

    encodeMD5Hex() {

        let encodeHex = byteStringObj.encodeUtf8('Hello world test test').md5().Hex();
        this.encodemd5HexValue = JSON.stringify(encodeHex);
        Log.showInfo("encodeMD5Hex -> encodemd5HexValue : " + this.encodemd5HexValue);

        var request = new okhttp.Request.Builder()
            .url(this.echoServer)
            .POST(okhttp.RequestBody.create(this.encodemd5HexValue))
            .addHeader("Content-Type", "application/json")
            .build();

        this.client.newCall(request).enqueue(this.onComplete, this.onError);
    },

    onHexDecodeComplete: function (result) {
        if (result.response) {
            this.status = result.response.responseCode;
        }
        if (result.response.result)
        this.content = result.response.result;
        else
        this.content = JSON.stringify(result.response);

        let decodehex = byteStringObj.decodeHex(this.content);
        this.decodeHexValue = JSON.stringify(decodehex);

        Log.showInfo("onHexDecodeComplete -> Status : " + this.status);
        Log.showInfo("onHexDecodeComplete -> Content : " + this.content);
        Log.showInfo("onHexDecodeComplete -> decodeHexValue : " + this.decodeHexValue);
    },

    onHexDecodeError: function (error) {
        this.status = "";
        this.content = error.data;
        Log.showInfo("onHexDecodeError -> Error : " + this.content);
    },

    okhttpDecodeHex() {

        var request = new okhttp.Request.Builder()
            .GET(this.ioServer)
            .addHeader("Content-Type", "application/json")
            .build();


        this.client.newCall(request).enqueue(this.onHexDecodeComplete, this.onHexDecodeError);
    },
    createFile(path){
        return fileio.openSync(path, 0o100, 0o666)
    },
    readFile(){
        var self = this;
        var path;
        var fileName = "/test.txt"
        featureAbility.getContext().getFilesDir().then((data) => {
            path=data+fileName;
            var sink = new okio.Sink(path);
            const test = "hello, world!  adjasjdakjdakjdkjakjdakjskjasdkjaskjdajksdkjasdkjaksjdkja\n"
            + "adasajsdkjadjkakjdakjsdkjadkjakjdakjsdkjasdkjaskjdakjsdkjaskjdakjsdkjaskjakjdakjs\n"
            + "adasajsdkjadjkakjdakjsdkjadkjakjdakjsdkjasdkjaskjdakjsdkjaskjdakjsdkjaskjakjdakjs\n"
            + "adasajsdkjadjkakjdakjsdkjadkjakjdakjsdkjasdkjaskjdakjsdkjaskjdakjsdkjaskjakjdakjs\n"
            + "adasajsdkjadjkakjdakjsdkjadkjakjdakjsdkjasdkjaskjdakjsdkjaskjdakjsdkjaskjakjdakjs\n"
            + "adasajsdkjadjkakjdakjsdkjadkjakjdakjsdkjasdkjaskjdakjsdkjaskjdakjsdkjaskjakjdakjs\n"

            sink.write(test,false);
            //read data
            var source = new okio.Source(path);
            source.read().then((data) => {
               // self.fileContent = data;
                Log.showInfo("fileCOntent : "+data)
            }).catch((error) => {
            });

        }).catch((err)=>{
            Log.showInfo("okio: path inside catch"+err);
        })

    }
    ,
    appendFile(){
        var self = this;
        var path;
        var fileName = "/test1.txt"
        featureAbility.getContext().getFilesDir().then((data) => {
            path=data+fileName;
            var sink = new okio.Sink(path);
            const test = "hello, world! "
            sink.write(test,true);
            //read data
            var source = new okio.Source(path);
            source.read().then((data) => {
               // self.fileContent = data;
                Log.showInfo("fileCOntent : "+data)
            }).catch((error) => {
            });

        }).catch((err)=>{
            Log.showInfo("okio: path inside catch"+err);
        })

    }
}
