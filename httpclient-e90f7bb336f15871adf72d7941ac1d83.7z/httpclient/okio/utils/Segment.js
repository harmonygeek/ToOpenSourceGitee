/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {util} from './Utilities.js';
import {SegmentPool} from './SegmentPool.js';

export function Segment() {
    Segment$Companion_getInstance();
    this.data = null;
    this.pos = 0;
    this.limit = 0;
    this.shared = false;
    this.owner = false;
    this.next = null;
    this.prev = null;
}
Segment.prototype.sharedCopy = function () {
    this.shared = true;
    return Segment_init_0(this.data, this.pos, this.limit, true, false);
};
Segment.prototype.unsharedCopy = function () {
    return Segment_init_0(this.data.slice(), this.pos, this.limit, false, true);
};
Segment.prototype.pop = function () {
    var result = this.next !== this ? this.next : null;
    util.ensureNotNull(this.prev).next = this.next;
    util.ensureNotNull(this.next).prev = this.prev;
    this.next = null;
    this.prev = null;
    return result;
};
Segment.prototype.push_uve4t5$ = function (segment) {
    segment.prev = this;
    segment.next = this.next;
    util.ensureNotNull(this.next).prev = segment;
    this.next = segment;
    return segment;
};
Segment.prototype.split_za3lpa$ = function (byteCount) {
    var arrayCopy = util.collections.arrayCopy;
    if (!(byteCount > 0 && byteCount <= (this.limit - this.pos | 0))) {
        var message = 'byteCount out of range';
        throw util.IllegalArgumentException_init(message.toString());
    }var prefix;
    if (byteCount >= 1024) {
        prefix = this.sharedCopy();
    } else {
        prefix = SegmentPool.SegmentPool_getInstance().take();
        arrayCopy(this.data, prefix.data, 0, this.pos, this.pos + byteCount | 0);
    }
    prefix.limit = prefix.pos + byteCount | 0;
    this.pos = this.pos + byteCount | 0;
    util.ensureNotNull(this.prev).push_uve4t5$(prefix);
    return prefix;
};
Segment.prototype.compact = function () {
    if (!(this.prev !== this)) {
        var message = 'cannot compact';
        throw util.IllegalStateException_init(message.toString());
    }if (!util.ensureNotNull(this.prev).owner)
    return;
    var byteCount = this.limit - this.pos | 0;
    var availableByteCount = 8192 - util.ensureNotNull(this.prev).limit + (util.ensureNotNull(this.prev).shared ? 0 : util.ensureNotNull(this.prev).pos) | 0;
    if (byteCount > availableByteCount)
    return;
    this.writeTo_l53ny1$(util.ensureNotNull(this.prev), byteCount);
    this.pop();
    SegmentPool.SegmentPool_getInstance().recycle_uve4t5$(this);
};
Segment.prototype.writeTo_l53ny1$ = function (sink, byteCount) {
    var arrayCopy = util.collections.arrayCopy;
    if (!sink.owner) {
        var message = 'only owner can write';
        throw util.IllegalStateException_init(message.toString());
    }if ((sink.limit + byteCount | 0) > 8192) {
        if (sink.shared)
        throw util.IllegalArgumentException_init_0();
        if ((sink.limit + byteCount - sink.pos | 0) > 8192)
        throw util.IllegalArgumentException_init_0();
        arrayCopy(sink.data, sink.data, 0, sink.pos, sink.limit);
        sink.limit = sink.limit - sink.pos | 0;
        sink.pos = 0;
    }arrayCopy(this.data, sink.data, sink.limit, this.pos, this.pos + byteCount | 0);
    sink.limit = sink.limit + byteCount | 0;
    this.pos = this.pos + byteCount | 0;
};
function Segment$Companion() {
    Segment$Companion_instance = this;
    this.SIZE = 8192;
    this.SHARE_MINIMUM = 1024;
}
Segment$Companion.$metadata$ = {
    kind: util.Kind.Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
};
var Segment$Companion_instance = null;
function Segment$Companion_getInstance() {
    if (Segment$Companion_instance === null) {
        new Segment$Companion();
    }return Segment$Companion_instance;
}
Segment.$metadata$ = {
    kind: util.Kind.Kind_CLASS,
    simpleName: 'Segment',
    interfaces: []
};

function Segment_init_0(data, pos, limit, shared, owner, $this) {
    $this = $this || Object.create(Segment.prototype);
    Segment.call($this);
    $this.data = data;
    $this.pos = pos;
    $this.limit = limit;
    $this.shared = shared;
    $this.owner = owner;
    return $this;
}