/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * the Request Object
 * @name Request
 * @since 1.0.0
 * @sysCap AAFwk
 * @devices phone, tablet
 * @permission N/A
 */
declare namespace Request {

    /**
    * constructor
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param build - Builder object
    * @return Returns the Request object
    */
    Request(build): function;

    /**
    * adds specific header to the headerlist.
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param key : header key
    * @param value : header value
    */
    addHeader(key, value): void;

    /**
    * setter function to set the request body
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param body value
    */
    set body(value) : void;

    /**
    * getter function to get the request headers
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return request headers
    */
    get headers() : var;

    /**
    * getter function to get the body
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return body
    */
    get body() : var;

    /**
    * getter function to get the url
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return url
    */
    get url() : var;

    /**
    * getter function to get the tag
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return tag
    */
    get tag() : var;

    /**
    * getter function to get the method
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return method
    */
    get method() : var;

    /**
    * getter function to get the queryParams
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return queryParams
    */
    get queryParams() : var;

    /**
    * getter function to get the params
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return params
    */
    get params() : var;

    /**
    * getter function to get the interceptors
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return interceptors
    */
    get interceptors() : var;

    /**
    * getter function to get the followRedirects
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return followRedirects
    */
    get followRedirects() : var;

    /**
    * getter function to get the retryOnConnectionFailure
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return retryOnConnectionFailure
    */
    get retryOnConnectionFailure() : var;

    /**
    * getter function to get the retryMaxLimit
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return retryMaxLimit
    */
    get retryMaxLimit() : var;

    /**
    * getter function to get the retryConnectionCount
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return retryConnectionCount
    */
    get retryConnectionCount() : var;

    /**
    * getter function to get the redirectMaxLimit
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return redirectMaxLimit
    */
    get redirectMaxLimit() : var;

    /**
    * getter function to get the cookieJar
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return cookieJar
    */
    get cookieJar() : var;

    /**
    * getter function to get the cookieManager
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return cookieManager
    */
    get cookieManager() : var;

    /**
    * setter function to set the url
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param url
    */
    set url(urlString) : void;

    /**
    * setter function to set the retryConnectionCount
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param count
    */
    set retryConnectionCount(count) : void;

    /**
    * setter function to set the redirectionCount
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param count
    */
    set redirectionCount(count) : void;

    class Builder {
        /**
        * constructor
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return creates and returns an object of Builder
        */
        Builder() : function;

        /**
        * adds cookie jar to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param cookieJar
        * @return returns the object of Builder
        */
        cookieJar(cookieJar) : Builder;

        /**
        * adds cookie Manager to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param cookieJar
        * @return returns the object of Builder
        */
        cookieManager(cookieManager) : Builder;

        /**
        * set retryOnConnectionFailure to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param retryOnConnectionFailure value
        * @return returns the object of Builder
        */
        retryOnConnectionFailure(isRetryOnConnectionFailure) : Builder;

        /**
        * set retryMaxLimit to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param max value
        * @return returns the object of Builder
        */
        retryMaxLimit(maxValue) : Builder;

        /**
        * set retryConnectionCount to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param count
        * @return returns the object of Builder
        */
        retryConnectionCount(count) : Builder;

        /**
        * set followRedirects to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param aFollowRedirects
        * @return returns the object of Builder
        */
        followRedirects(aFollowRedirects) : Builder;

        /**
        * set redirectMaxLimit to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param maxValue
        * @return returns the object of Builder
        */
        redirectMaxLimit(maxValue) : Builder;

        /**
        * set redirectionCount to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param count
        * @return returns the object of Builder
        */
        redirectionCount(maxValue) : Builder;

        /**
        * adds headers to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param headers value
        * @return returns the object of Builder
        */
        headers(value) : Builder;

        /**
        * adds specific header to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param headers value
        * @return returns the object of Builder
        */
        addHeader(key, value) : Builder;

        /**
        * adds body to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param body value
        * @return returns the object of Builder
        */
        body(value) : Builder;

        /**
        * adds url to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param url value
        * @return returns the object of Builder
        */
        url(value) : Builder;

        /**
        * adds tag to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param tag value
        * @return returns the object of Builder
        */
        tag(value) : Builder;

        /**
        * sets the request method to GET in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @return returns the object of Builder
        */
        GET() : Builder;

        /**
        * sets the request method to PUT in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param body
        * @return returns the object of Builder
        */
        PUT(body) : Builder;

        /**
        * sets the request method to DELETE in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @return returns the object of Builder
        */
        DELETE() : Builder;

        /**
        * sets the request method to HEAD in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @return returns the object of Builder
        */
        HEAD() : Builder;

        /**
        * sets the request method to POST in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @return returns the object of Builder
        */
        POST() : Builder;

        /**
        * sets the request method in builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param method
        * @return returns the object of Builder
        */
        REQUEST(method) : Builder;

        /**
        * builds the Request object using Builder object instance
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return returns the object of Request
        */
        build() : Request;
    }

}

export default Request;