/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * the Mime Object
 * @name Mime
 * @since 1.0.0
 * @sysCap AAFwk
 * @devices phone, tablet
 * @permission N/A
 */
declare namespace Mime {


    /**
    * constructor
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param build - Builder object
    * @return creates and returns an object of FileUpload
    */
    Mime(build) : function;

    /**
    * Get mime type
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @param none
    * @return returns the mimetype
    */
    getMime(): var;

    class Builder {
        /**
        * constructor
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return creates and returns an object of Builder
        */
        Builder() : function;

        /**
        * adds content type to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param content type value
        * @return returns the object of Builder
        */
        contentType(value) : Builder;

        /**
        * adds version to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param version value
        * @return returns the object of Builder
        */
        version(value) : Builder;

        /**
        * adds contentID to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param content id value
        * @return returns the object of Builder
        */
        contentID(value) : Builder;

        /**
        * builds the Mime object using Builder object instance
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return returns the object of Mime
        */
        build() : Mime;
    }
}

export default Mime;