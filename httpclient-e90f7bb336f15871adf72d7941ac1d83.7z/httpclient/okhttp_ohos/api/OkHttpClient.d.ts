/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * the OkHttpClient Object
 * @name OkHttpClient
 * @since 1.0.0
 * @sysCap AAFwk
 * @devices phone, tablet
 * @permission INTERNET
 */
declare namespace OkHttpClient {

    /**
    * constructor
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param build - Builder object
    * @return creates and returns an object of OkHttpClient
    */
    OkHttpClient(build) : function;

    /**
    * Encapsulates a request object into a httpcall object
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @param request
    */
    newCall(request): httpcall;

    /**
    * getter function to get the dispatcher
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return dispatcher
    */
    get dispatcher() : var;

    /**
    * getter function to get the interceptors
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return interceptors
    */
    get interceptors() : var;

    /**
    * getter function to get the readTimeout
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return readTimeout
    */
    get readTimeout() : var;

    /**
    * getter function to get the writeTimeout
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return writeTimeout
    */
    get writeTimeout() : var;

    /**
    * cancels the request by tag
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @return tagKey
    */
    cancelRequestByTag(tagKey) : var;

    class Builder {
        /**
        * constructor
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return creates and returns an object of Builder
        */
        Builder() : function;

        /**
        * adds interceptor to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param interceptor
        * @return returns the object of Builder
        */
        addInterceptor(aInterceptor) : Builder;

        /**
        * adds connect time out to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param timeout
        * @return returns the object of Builder
        */
        setConnectTimeout(timeout, unit) : Builder;

        /**
        * adds read time out to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param timeout
        * @return returns the object of Builder
        */
        setReadTimeout(timeout, unit) : Builder;

        /**
        * adds write time out to builder object
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param timeout
        * @return returns the object of Builder
        */
        setWriteTimeout(timeout, unit) : Builder;

        /**
        * builds the OkHttpClient object using Builder object instance
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return returns the object of OkHttpClient
        */
        build() : OkHttpClient;
    }
}

export default OkHttpClient;