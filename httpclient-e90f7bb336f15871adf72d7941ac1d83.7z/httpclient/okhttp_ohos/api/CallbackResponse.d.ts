/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * the CallbackResponse Object
 * @name Cookie
 * @since 1.0.0
 * @sysCap AAFwk
 * @devices phone, tablet
 * @permission N/A
 */
declare namespace CallbackResponse {

    /**
    * constructor
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param response body to convert, rawResponse
    * @return NA
    */
    CallbackResponse(body,rawResponse): function;

     /**
    * get the response code  from raw response .
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param NA
    * @return Returns the response code from raw response
    */
    code(): function;


     /**
    * get the result from raw response .
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param NA
    * @return Returns the result from raw response
    */
    result(): function;

    /**
    * get the header from raw response
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param NA
    * @return Returns the header object
    */
    header(): function;
     /**
    * get the converted response
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param NA
    * @return Returns the converted response
    */
    body(): function;

    /**
    * get the raw response
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param NA
    * @return Returns the raw response
    */
    rawResponse(): function;
}

export default CallbackResponse;