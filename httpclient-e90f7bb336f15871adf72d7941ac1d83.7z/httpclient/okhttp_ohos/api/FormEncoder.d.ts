/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * the FormEncodingBuilder Object
 * @name FormEncodingBuilder
 * @since 1.0.0
 * @sysCap AAFwk
 * @devices phone, tablet
 * @permission N/A
 */
declare namespace FormEncoder {
    /**
    * constructor
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param build - Builder object
    * @return creates and returns an object of FormEncoder
    */
    FormEncoder(build) : function;

    /**
    * Create request body instance
    *
    * @devices phone, tablet
    * @since 1.0.0
    * @sysCap AAFwk
    * @param name key name
    * @return returns RequestBody instance
    */
    createRequestBody() : RequestBody;

    class Builder {
        /**
        * constructor
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return creates and returns an object of Builder
        */
        Builder() : function;

        /**
        * adds encoded query param
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param file uri
        * @return returns the object of Builder
        */
        add(name, value) : Builder;

        /**
        * builds the FileUpload object using Builder object instance
        * @devices phone, tablet
        * @since 1.0.0
        * @sysCap AAFwk
        * @param none
        * @return returns the object of FormEncoder
        */
        build() : FormEncoder;
    }
}

export default FormEncoder;